<?php include('config/database_functions.php'); 
    // $send_sms = send_sms($destination_no, $message, $developer_id, $cloud_sms_password);
     send_sms_smart('A customer just signed up on jupet website',2,'08168509044');
    // echo send_sms_smart('testing',2,'08123592660');
    // echo send_sms_smart('testing sms message',2,'09018967832');
?>