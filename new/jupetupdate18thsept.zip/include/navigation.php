<div class="col-lg-3 col-md-6">
    <div class="checkout__order">
    <h4>Navigation</h4>
    <ul>
    <li><a href="home.php">Dashboard</a></li>
    <li><a href="home.php" style="text-decoration:none; color: #007bff;">All Orders</a></li>
    <li><a href="pending_orders.php" style="text-decoration:none; color: #007bff;">My Pending Orders</a></li>
    <li><a href="completed_orders.php" style="text-decoration:none; color: #007bff;">Completed Orders</a></li>
    <li><a href="delivered_orders.php" style="text-decoration:none; color: #007bff;">Delivered Orders</a></li>
    <li><a href="empty_cart.php" style="text-decoration:none; color: #007bff;">Empty Cart</a></li>
    <li><a href="logout.php" style="text-decoration:none; color: #007bff;">Logout</a></li>
    </ul>
    </div>
</div>