<?php session_start();
include('config/database_functions.php'); 
include('include/header.php'); 
unset($_SESSION['cart']);

//get all products
$products = get_rows_from_one_table('product_tbl','date_added');

if(!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
 }

if(isset($_POST['cmd_add_to_cart'])){
    $quantity = $_POST['quantity'];
    $product_id = $_POST['product_id'];
    $combo = $product_id.'_'.$quantity;
    array_push($_SESSION['cart'], $combo  ) ;
    $cart_session_array = $_SESSION['cart'];
    // $add_to_cart = add_to_cart($cart_session_array,$quantity,$product_id);
}

echo json_encode($_SESSION['cart']);

?>
<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Humberger Begin -->
    <div class="humberger__menu__overlay"></div>
    <div class="humberger__menu__wrapper">
        <div class="humberger__menu__logo">
            <a href="#">
                <img src="img/logo.jpg" width="190" height="190" alt="">
            </a>
        </div>
        <div class="humberger__menu__cart">
            <ul>
                
                <li><a href="#"><i class="fa fa-shopping-bag"></i> <span>0</span></a></li>
            </ul>
            <div class="header__cart__price">item: <span>&#8358;150.00</span></div>
        </div>
        <div class="humberger__menu__widget">
            <!-- <div class="header__top__right__language">
                <img src="img/language.png" alt="">
                <div>English</div>
                <span class="arrow_carrot-down"></span>
                <ul>
                    <li><a href="#">Spanis</a></li>
                    <li><a href="#">English</a></li>
                </ul>
            </div> -->
            <div class="header__top__right__auth">
                <a href="#"><i class="fa fa-user"></i> Login</a>
            </div>
        </div>
        <nav class="humberger__menu__nav mobile-menu">
            <ul>
              <li class="active"><a href="index.php">Home</a></li>
                            <li><a href="#">Products</a></li>
                            <li><a href="#">Contact</a></li>
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="header__top__right__social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-pinterest-p"></i></a>
        </div>
        <div class="humberger__menu__contact">
            <ul>
                <li><i class="fa fa-envelope"></i> support@jupetfarmfresh.com</li>
                <li><i class="fa fa-envelope"></i>  Call:  +234 8151281541, 08101493108 Whatsapp:  +234 8151281541, 08101493108, support 24/7 time support</li>
            </ul>
        </div>
    </div>
    <!-- Humberger End -->

    <!-- Header Section Begin -->
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-6">
                        <div class="header__top__left">
                            <ul>
                                <li><i class="fa fa-envelope"></i> support@jupetfarmfresh.com</li>
                                 <li><i class="fa fa-phone"></i>  Call/Whatsapp:  +234 8151281541, 08101493108</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="header__top__right">
                            <div class="header__top__right__social">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-pinterest-p"></i></a>
                            </div>
                            <!-- <div class="header__top__right__language">
                                <img src="img/language.png" alt="">
                                <div>English</div>
                                <span class="arrow_carrot-down"></span>
                                <ul>
                                    <li><a href="#">Spanis</a></li>
                                    <li><a href="#">English</a></li>
                                </ul>
                            </div> -->
                            <div class="header__top__right__auth">
                                <a href="#"><i class="fa fa-user"></i> Login</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="header__logo">
                        <a href="#">
                         <img width="100" height="80" src="img/logo.jpg" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="header__menu">
                        <ul>
                            <li class="active"><a href="index.php">Home</a></li>
                            <li><a href="#">Products</a></li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-3">
                    <div class="header__cart">
                        <ul>
                       
                            <li><a href="#"><i class="fa fa-shopping-bag"></i> <span>0</span></a></li>
                        </ul>
                        <div class="header__cart__price">item: <span>&#8358;150.00</span></div>
                    </div>
                </div>
            </div>
            <div class="humberger__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header Section End -->

    <!-- Hero Section Begin -->
    <section class="hero">
        <div class="container">
            <div class="row">
              
                <div class="col-lg-12">
                   <!--  <div class="hero__search">
                       
                        <div class="hero__search__phone">
                            <div class="hero__search__phone__icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="hero__search__phone__text">
                                <h5>+44 7999 372481</h5>
                                <span>support 24/7 time</span>
                            </div>
                        </div>
                    </div> -->
                    <div class="hero__item set-bg" data-setbg="img/banner/banner.jpg">
                        <div class="hero__text">
                            <span>FARM FRESH</span>
                            <h2>Chicken, Turkey, <br>Goat Meat <br /> 100% Farm Fresh</h2>
                            <p>Free Pickup and Delivery Available</p>
                            <a href="#" class="primary-btn">SHOP NOW</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->


   <!-- Featured Section Begin -->
    <section class="featured spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Our Products</h2>
                    </div>
                   <!--  <div class="featured__controls">
                        <ul>
                            <li class="active" data-filter="*">All</li>
                            <li data-filter=".oranges">Oranges</li>
                            <li data-filter=".fresh-meat">Fresh Meat</li>
                            <li data-filter=".vegetables">Vegetables</li>
                            <li data-filter=".fastfood">Fastfood</li>
                        </ul>
                    </div> -->
                </div>
            </div>
            <div class="row featured__filter">

                <?php foreach($products as $product){ ?>
                <div class="col-lg-4 col-md-4 col-sm-6 mix oranges fresh-meat">
                    <div class="featured__item">
                        <div class="featured__item__pic set-bg" data-setbg="<?php echo $product['product_path']; ?>">
                            <!-- <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul> -->
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="#"><?php echo $product['product_name'].'---'.$product['product_path'] ;?></a></h6>
                            <h5>&#8358;<?php echo $product['unit_price'];?></h5>
                             <form action="" method="post">
                                <div style="margin-left: 100px ;">
                                    <div class="input-group mb-3">
                                        <input required="required" type="text" name="quantity" id="quantity" class="form-control col-6" placeholder="enter quantity" aria-label="enter quantity" aria-describedby="enter quantity">
                                        <div class="input-group-append">
                                        <input type="submit" id="cmd_add_to_cart" name="cmd_add_to_cart" class="btn btn-success" type="button" value="Buy">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php } ?>

                <div class="col-lg-4 col-md-4 col-sm-6 mix vegetables fastfood">
                    <div class="featured__item">
                        <div class="featured__item__pic set-bg" data-setbg="products/frozen-turkey.jpg">
                            <!-- <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul> -->
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="#">Farm Fresh Turkey</a></h6>
                            <h5>&#8358;30.00</h5>
                             <form action="" method="post">
                                <div style="margin-left: 100px ;">
                                    <div class="input-group mb-3">
                                        <input required="required" type="text" name="quantity" id="quantity" class="form-control col-6" placeholder="enter quantity" aria-label="enter quantity" aria-describedby="enter quantity">
                                        <div class="input-group-append">
                                        <input type="submit" id="cmd_add_to_cart" name="cmd_add_to_cart" class="btn btn-success" type="button" value="Buy">
                                        </div>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 mix vegetables fresh-meat">
                    <div class="featured__item">
                        <div class="featured__item__pic set-bg" data-setbg="products/frozen-goat-meat.jpg">
                            <!-- <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul> -->
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="#">Farm Fresh Goat Meat</a></h6>
                            <h5>&#8358;30.00</h5>
                            <form action="" method="post">
                                <div style="margin-left: 100px ;">
                                    <div class="input-group mb-3">
                                        <input required="required" type="text" name="quantity" id="quantity" class="form-control col-6" placeholder="enter quantity" aria-label="enter quantity" aria-describedby="enter quantity">
                                        <div class="input-group-append">
                                        <input type="submit" id="cmd_add_to_cart" name="cmd_add_to_cart" class="btn btn-success" type="button" value="Buy">
                                        </div>
                                    </div>
                                </div>
                            </form>

  
                    

                        </div>
                    </div>
                </div>
              <!--   <div class="col-lg-6 col-md-4 col-sm-6 mix fastfood oranges">
                    <div class="featured__item">
                        <div class="featured__item__pic set-bg" data-setbg="img/featured/feature-4.jpg">
                            <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="#">Crab Pool Security</a></h6>
                            <h5>&#8358;30.00</h5>
                            <button class="btn btn-sm btn-success">add to cart</button>

                        </div>
                    </div>
                </div> -->
           
            </div>
        </div>
    </section>
    <!-- Featured Section End -->


 <?php include('include/footer.php'); ?>